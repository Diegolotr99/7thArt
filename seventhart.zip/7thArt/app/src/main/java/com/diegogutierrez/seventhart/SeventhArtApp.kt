package com.diegogutierrez.seventhart

import android.app.Application

class SeventhArtApp : Application() {
    override fun onCreate() {
        super.onCreate()
        initDI()
    }
}