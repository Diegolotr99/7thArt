package com.diegogutierrez.testshared
import com.diegogutierrez.domain.Movie

val mockedMovie = Movie(
    0,
    "Title",
    "Overview",
    "01/01/2025",
    "",
    "",
    "EN",
    "Title",
    5.0,
    5.1,
    false
)