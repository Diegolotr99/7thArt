# 7thArt
![SeventhArt](https://i.ibb.co/xDp2V5w/7th-art-logo-circle-200.png)

Project for Architect Coders course. 

Diego Gutierrez Castro

App interacting with TheMovieDB api. 

Using Clean Architecture, Dependency Injection with Koin, Tests
